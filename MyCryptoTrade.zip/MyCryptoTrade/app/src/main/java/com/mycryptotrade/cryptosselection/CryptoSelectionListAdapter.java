package com.mycryptotrade.cryptosselection;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mycryptotrade.R;
import com.mycryptotrade.clients.firebase.Firestore;
import com.mycryptotrade.clients.firebase.MyCallback;
import com.mycryptotrade.utils.Utils;

import java.lang.reflect.Array;
import java.security.KeyException;
import java.util.ArrayList;
import java.util.HashMap;

public class CryptoSelectionListAdapter extends RecyclerView.Adapter<CryptoSelectionListAdapter.ViewHolder>{

    private Context context;
    private ArrayList<CryptoAssets> currencies;

    private ArrayList<CryptoAssets> selectedCryptos = new ArrayList<>();
    private HashMap<String, CryptoAssets> savedCryptos;

    public CryptoSelectionListAdapter(Context context){
        this.context = context;
        if(this.getSavedCryptos() == null){
            Firestore dbClient = new Firestore();
            dbClient.getCurrencies(new MyCallback() {
                @Override
                public void onCallback(ArrayList<String> result) {
                    HashMap<String, CryptoAssets> savedFavouriteList = new HashMap<>();
                    for(String coin : result) {
                        CryptoAssets c = CryptoAssets.transformStringCoinToObject(coin);
                        savedFavouriteList.put(c.getAssetFullName(), c);
                    }
                    setSavedCryptos(savedFavouriteList);
                }
            });
        }
    }

    @NonNull
    @Override
    public CryptoSelectionListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.crypto_card_list, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CryptoSelectionListAdapter.ViewHolder holder, int position) {
        CryptoAssets coin = this.currencies.get(position);
        holder.checkBox.setText(coin.getAssetFullName() + "(" + coin.getAssetName() + ")");

        try{
            CryptoAssets crypto = this.savedCryptos.get(coin.getAssetFullName());
            if(crypto != null) {
                holder.checkBox.setChecked(true);
            }
            else
                holder.checkBox.setChecked(false);

        }
        catch (NullPointerException ex){
        }

        // if the checkbox is clicked
        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(holder.checkBox.isChecked()){
                    String coinText = holder.checkBox.getText().toString();
                    selectedCryptos.add(CryptoAssets.transformStringCoinToObject(coinText));
                }
                else{
                    String coinText = holder.checkBox.getText().toString();
                    CryptoAssets crypto = CryptoAssets.transformStringCoinToObject(coinText);
                    selectedCryptos.remove(crypto);
                }
            }
        });


        // if not clicked and it is checked
        if(holder.checkBox.isChecked()){
            String coinText = holder.checkBox.getText().toString();
            selectedCryptos.add(CryptoAssets.transformStringCoinToObject(coinText));
        }

        Drawable d = Utils.loadImage(coin, context);
        holder.imageView.setImageDrawable(d);
    }

    @Override
    public int getItemCount() {
        if(this.currencies != null)
            return this.currencies.size();
        else
            return 0;
    }

    public void setCurrencies(ArrayList<CryptoAssets> currencies) {
        this.currencies = currencies;
    }

    public ArrayList<CryptoAssets> getSelectedCryptos() {
        return selectedCryptos;
    }

    public void setSelectedCryptos(ArrayList<CryptoAssets> selectedCryptos) {
        this.selectedCryptos = selectedCryptos;
    }

    public HashMap<String, CryptoAssets> getSavedCryptos() {
        return savedCryptos;
    }

    public void setSavedCryptos(HashMap<String, CryptoAssets> savedCryptos) {
        this.savedCryptos = savedCryptos;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.checkBox = (CheckBox) itemView.findViewById(R.id.crypto_list_check_box);
            this.imageView = (ImageView) itemView.findViewById(R.id.card_with_checkbox_image);
        }
    }
}
