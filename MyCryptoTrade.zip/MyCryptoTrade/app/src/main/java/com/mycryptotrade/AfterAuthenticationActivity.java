package com.mycryptotrade;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mycryptotrade.authentication.LogInActivity;
import com.mycryptotrade.fragments.FavouriteCryptoCurrenciesFragment;
import com.mycryptotrade.fragments.HomeFragment;
import com.mycryptotrade.fragments.MetricsFragment;
import com.mycryptotrade.fragments.NewsFragment;
import com.mycryptotrade.fragments.NotificationsFragment;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

public class AfterAuthenticationActivity extends AppCompatActivity {

    private final static String TAG = "AfterAuthenticationActivity";

    HashMap<String, Intent> runningServices = new HashMap<>();

    private BottomNavigationView.OnNavigationItemSelectedListener navListener = new
            BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull @NotNull MenuItem item) {
                    Fragment selectedFragment = null;
                    switch (item.getItemId()){
                        case R.id.home_button:
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            selectedFragment = HomeFragment.newInstance(user);
                            break;
                        case R.id.favourite_list_button:
                            selectedFragment = new FavouriteCryptoCurrenciesFragment();
                            break;
                        case R.id.metrics_button:
                            selectedFragment = new MetricsFragment();
                            break;
                        case R.id.news_button:
                            selectedFragment = new NewsFragment();
                            break;
                        case R.id.notifications_button:
                            selectedFragment = new NotificationsFragment();
                            break;
                    }

                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_layout,
                                    selectedFragment)
                            .commit();

                    return true;
                }
            };

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_authentication);

        BottomNavigationView bntNav = findViewById(R.id.bottomNavigationview);
        bntNav.setOnNavigationItemSelectedListener(navListener);

        // Setting a default fragment
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_layout, HomeFragment.newInstance(user))
                .commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.log_out:
                signOutFromMenu();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void signOutFromMenu(){
        FirebaseAuth.getInstance().signOut();
        signOut();
    }

    private void signOut() {
        AuthUI.getInstance()
                .signOut(this)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    public void onComplete(@NonNull Task<Void> task) {
                        redirectToMainActivity();
                    }
                });
    }

    private void redirectToMainActivity(){
        if(FirebaseAuth.getInstance().getCurrentUser() == null){
            Intent logIn = new Intent(this, LogInActivity.class);
            startActivity(logIn);
            finish();
        }
    }

    public void setRunningServices(HashMap<String, Intent> runningServices) {
        this.runningServices = runningServices;
    }

    public void setRunningService(String coin, Intent i){
        this.runningServices.put(coin, i);
    }

    public Intent getRunningService(String coin){
        return this.runningServices.get(coin);
    }

    public void removeRunningService(String coin){
        this.runningServices.remove(coin);
    }

    public HashMap<String, Intent> getRunningServices() {
        return runningServices;
    }
}
