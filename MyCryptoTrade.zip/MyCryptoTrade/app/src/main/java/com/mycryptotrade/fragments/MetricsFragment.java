package com.mycryptotrade.fragments;

import android.content.res.Configuration;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.mycryptotrade.R;
import com.mycryptotrade.cryptos.CryptoCurrenciesInformationLoader;
import com.mycryptotrade.cryptos.MetricsAdapter;
import com.mycryptotrade.cryptos.MetricsTransfer;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MetricsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MetricsFragment extends Fragment {

    private final static String TAG = "MetricsFragment";
    private int CRYPTOCURRENCIES_LOADER_ID = 0;

    private RecyclerView recyclerView;
    private MetricsAdapter adapter;

    private MetricsFragment.CryptoCurrenciesLoaderCallbacks cryptosLoaderCallbacks = new MetricsFragment.CryptoCurrenciesLoaderCallbacks();

    public MetricsFragment() {
        // Required empty public constructor
    }

    public static MetricsFragment newInstance() {
        MetricsFragment fragment = new MetricsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        int orientation = getActivity().getResources().getConfiguration().orientation;

        View view;

        if(orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Inflate the layout for this fragment
            view = inflater.inflate(R.layout.fragment_metrics, container, false);
        }
        else{
            // orientation landscape
            view = inflater.inflate(R.layout.fragment_metrics_landscape, container, false);
        }

        LoaderManager loaderManager = LoaderManager.getInstance(this);
        if(loaderManager.getLoader(CRYPTOCURRENCIES_LOADER_ID) != null){
            loaderManager.initLoader(CRYPTOCURRENCIES_LOADER_ID,null, cryptosLoaderCallbacks);
        }

        this.recyclerView = (RecyclerView)view.findViewById(R.id.metrics_recycler_view);
        this.adapter = new MetricsAdapter(view.getContext());

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        getMetrics();

        return view;
    }

    private void getMetrics() {
        Bundle queryBundle = new Bundle();
        //queryBundle.putString(BookLoaderCallbacks.EXTRA_QUERY, queryString);
        //queryBundle.putString(BookLoaderCallbacks.EXTRA_PRINT_TYPE, typeSelected);
        LoaderManager.getInstance(this).restartLoader(CRYPTOCURRENCIES_LOADER_ID, queryBundle, cryptosLoaderCallbacks);
    }

    void updateResultList(List<MetricsTransfer> coins){
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter.setCoins(new ArrayList<>(coins));
        adapter.notifyDataSetChanged();
    }

    public class CryptoCurrenciesLoaderCallbacks implements LoaderManager.LoaderCallbacks<List<MetricsTransfer>> {
        @NonNull
        @Override
        public Loader<List<MetricsTransfer>> onCreateLoader(int id, @Nullable Bundle args) {
            Toast.makeText(getContext(), "Loading...", Toast.LENGTH_LONG).show();
            return new CryptoCurrenciesInformationLoader(getActivity());
        }

        @Override
        public void onLoadFinished(@NonNull Loader<List<MetricsTransfer>> loader, List<MetricsTransfer> data) {

            if (data.size() > 0) {
                updateResultList(data);
            }
            else {
                updateResultList(new ArrayList<MetricsTransfer>());
                Toast.makeText(getContext(), "Your favourite list is empty.", Toast.LENGTH_LONG).show();
            }
        }

        @Override
        public void onLoaderReset(@NonNull Loader<List<MetricsTransfer>> loader) {
            loader.reset();
            adapter.notifyDataSetChanged();
        }
    }
}