package com.mycryptotrade.cryptos;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.loader.content.AsyncTaskLoader;

import com.mycryptotrade.clients.RestClient;
import com.mycryptotrade.clients.RestClientImp;
import com.mycryptotrade.clients.TwitterClient;
import com.mycryptotrade.clients.firebase.Firestore;
import com.mycryptotrade.cryptosselection.CryptoAssets;
import com.mycryptotrade.twitter.Tweet;
import com.mycryptotrade.twitter.TweetInformation;
import com.mycryptotrade.twitter.TwitterUser;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MetricsLoader extends AsyncTaskLoader<List<TweetInformation>> {
    private static final String TAG = "TwitterTweetsLoader";
    private TwitterClient twitterClient;

    public MetricsLoader(@NonNull Context context) {
        super(context);

        RestClient client = new RestClientImp();
        this.twitterClient = client.createTwitterClient();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public List<TweetInformation> loadInBackground() {
        List<TweetInformation> tweetInformationList = new ArrayList<>();

        Firestore dbClient = new Firestore();
        ArrayList<CryptoAssets> favouriteList = dbClient.getFavouriteCryptoCurrenciesSynchronous();

        Log.e(TAG, "loadInBackground, favourite list: " + favouriteList);

        if(favouriteList != null){
            for(int j = 0; j < favouriteList.size() && j < 2; ++j){
                CryptoAssets currency = favouriteList.get(j);
                List<Tweet> tweets = this.twitterClient.getTweets(this.twitterClient.getTweetsForCurrency(currency.getAssetName()));

                //getting the users who have created the tweets
                List<TwitterUser> users = new ArrayList<>();
                for(Tweet t: tweets){
                    users.add(this.twitterClient.getTwitterUser(this.twitterClient.getTweetUser(t.getAuthor_id())));
                }

                //mapping the tweets to the users who have created them
                for(int i = 0; i < tweets.size(); ++i){
                    tweetInformationList.add(new TweetInformation(tweets.get(i), users.get(i)));
                }
            }
        }

        return tweetInformationList.stream().limit(20).collect(Collectors.toList());
    }

    public void onStartLoading(){
        this.forceLoad();
    }
}
