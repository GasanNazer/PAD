package com.mycryptotrade.cryptos;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.loader.content.AsyncTaskLoader;

import com.google.gson.JsonArray;
import com.mycryptotrade.clients.BinanceClient;
import com.mycryptotrade.clients.RestClient;
import com.mycryptotrade.clients.RestClientImp;
import com.mycryptotrade.clients.firebase.Firestore;
import com.mycryptotrade.cryptosselection.CryptoAssets;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class CryptoCurrenciesInformationLoader extends AsyncTaskLoader<List<MetricsTransfer>> {
    private BinanceClient binanceClient;

    public CryptoCurrenciesInformationLoader(@NonNull Context context) {
        super(context);

        RestClient client = new RestClientImp();
        this.binanceClient = client.createBinanceClient();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public List<MetricsTransfer> loadInBackground() {
        Firestore dbClient = new Firestore();
        ArrayList<CryptoAssets> favouriteList = dbClient.getFavouriteCryptoCurrenciesSynchronous();

        List<MetricsTransfer> result = new ArrayList<>();

        for(CryptoAssets coin : favouriteList){
            String symbol = coin.getAssetName() + "EUR";
            SymbolStatistics symbolStatistics = this.binanceClient.fromJsonResponse(this.binanceClient.getPriceChange24h(symbol));
            List<BinanceCandle> candles = this.binanceClient.getCandles(this.binanceClient.getCandlesInterval1HForLast24H(symbol));
            result.add(new MetricsTransfer(coin, symbolStatistics, candles));
        }

        return result;
    }

    public void onStartLoading(){
        this.forceLoad();
    }
}
