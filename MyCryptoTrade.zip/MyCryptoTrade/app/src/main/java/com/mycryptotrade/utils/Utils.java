package com.mycryptotrade.utils;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.util.Log;

import com.mycryptotrade.cryptosselection.CryptoAssets;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.Date;

public class Utils {

	private final static String TAG = "Utils";
	
	public static Date convertTimestampToDate(Long timestamp) {
		Timestamp ts = new Timestamp(timestamp);  
        Date date = new Date(ts.getTime()); 
        
        return date;
	}
	
	public static Long convertDateToTimestamp(Date date) {
		return date.getTime();
	}
	
	public static Date getDateNdaysFromNow(int n_days) {
		long DAY_IN_MS = 1000 * 60 * 60 * 24;
		
		return new Date(new Date().getTime() - (n_days * DAY_IN_MS));
	}

	public static Drawable loadImage(String coin, Context context) {
		AssetManager manager = context.getAssets();

		InputStream ims = null;
		try {
			ims = manager.open("cryptos/" + coin.toLowerCase() + ".png");
		} catch (IOException e) {

			try {
				ims = manager.open("cryptos/" + "generic.png");
			} catch (IOException ex){
				Log.e(TAG, "loadImage(CryptoAssets): " + e);
			}
		}
		// load image as Drawable
		Drawable d = Drawable.createFromStream(ims, null);

		return d;
	}

	public static Drawable loadImage(CryptoAssets coin, Context context) {
		AssetManager manager = context.getAssets();

		InputStream ims = null;
		try {
			ims = manager.open("cryptos/" + coin.getAssetName().toLowerCase() + ".png");
		} catch (IOException e) {

			try {
				ims = manager.open("cryptos/" + "generic.png");
			} catch (IOException ex){
				Log.e(TAG, "loadImage(CryptoAssets): " + e);
			}
		}
		// load image as Drawable
		Drawable d = Drawable.createFromStream(ims, null);

		return d;
	}
}
