package com.mycryptotrade.clients;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.google.gson.JsonObject;
import com.mycryptotrade.cryptosselection.CryptoAssets;
import com.mycryptotrade.twitter.Tweet;
import com.mycryptotrade.twitter.TwitterUser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TwitterClient extends RestClientBase{

	private static final String TAG = "TwitterClient";

	public static final String BASE_URL = "https://api.twitter.com/2";
	public static final String USERS_ENDPOINT = "/users/";
	public static final String SEARCH_TWEETS = "/tweets/search/recent";
	private static final String API_KEY_NAME = "Authorization";
	// not the best way to give this parameter in the feature it should be given as
	// an environment variable
	private static final String API_KEY_VALUE = "Bearer AAAAAAAAAAAAAAAAAAAAANcoOQEAAAAAiy0ioOxkUnp1AqLMk32gAAjcEvc%3DidhuErfwPdXD7XsmbxtXtxkenA0hnSxswFEML6hQf13JOkLDtZ";


	public TwitterClient() {
		this.setBaseUrl(BASE_URL);
	}

	@RequiresApi(api = Build.VERSION_CODES.N)
	public JSONObject getTweetsForCurrency(String currency) {
		String query = "?query=" + currency +
						"&max_results=10" +
						"&tweet.fields=author_id";

		String result = this.makeAsynchronousCallSecured(
				this.constructUrl(SEARCH_TWEETS + query),
				API_KEY_NAME,
				API_KEY_VALUE);

		JSONObject jsonObject = null;

		try {
			jsonObject = new JSONObject(result);
		}
		catch (JSONException ex){
			Log.e(TAG, "getTweetsForCurrency: " + ex);
		}

		return jsonObject;
	}

	@RequiresApi(api = Build.VERSION_CODES.N)
	public JSONObject getTweetUser(Long idUser) {

		String result = this.makeAsynchronousCallSecured(
				this.constructUrl(USERS_ENDPOINT + idUser),
				API_KEY_NAME,
				API_KEY_VALUE);

		JSONObject jsonObject = null;

		try {
			jsonObject = new JSONObject(result);
		}
		catch (JSONException ex){
			Log.e(TAG, "getTweetUser: " + ex);
		}

		return jsonObject;
	}

	public TwitterUser getTwitterUser(JSONObject jsonObject){
		TwitterUser result = null;

		try{
			JSONObject attributes = (JSONObject)jsonObject.get("data");
			result = new TwitterUser(
					attributes.getLong("id"),
					attributes.getString("name"),
					attributes.getString("username"));
		}
		catch(Exception ex){
			Log.e(TAG,"getTwitterUser() Could not find user: " + ex.getMessage());
			return new TwitterUser(null, "Unknown", "unknown");
		}

		return result;
	}


	public List<Tweet> getTweets(JSONObject jsonObject){
		List<Tweet> itemsFetched = new ArrayList<>();

		try{
			JSONArray tweets = (JSONArray)jsonObject.get("data");
			for (int i = 0; i < tweets.length(); i++)
			{
				JSONObject tweet = tweets.getJSONObject(i);
				Tweet t = new Tweet(
						tweet.getLong("author_id"),
						tweet.getLong("id"),
						tweet.getString("text")
				);

				itemsFetched.add(t);
			}
		}
		catch(Exception ex){
			Log.e(TAG,"getTweets: " + ex.getMessage());
		}

		return itemsFetched;
	}
}
