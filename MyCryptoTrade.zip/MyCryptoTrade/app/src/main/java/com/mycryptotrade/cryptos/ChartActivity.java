package com.mycryptotrade.cryptos;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.CandleStickChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.CandleData;
import com.github.mikephil.charting.data.CandleDataSet;
import com.github.mikephil.charting.data.CandleEntry;
import com.mycryptotrade.R;

import java.util.ArrayList;

public class ChartActivity extends AppCompatActivity {

    private ArrayList<BinanceCandle> candles;
    private String coinName;
    private double minValue;
    private double maxValue;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.metrics_chart);
        Intent i = getIntent();
        this.candles = (ArrayList)i.getSerializableExtra("data");
        this.coinName = i.getStringExtra("coinName");
        this.minValue = i.getDoubleExtra("min",0);
        this.maxValue = i.getDoubleExtra("max",1000);
        createChart();
    }

    private void createChart(){
        CandleStickChart candleStickChart = findViewById(R.id.candle_stick_chart);
        candleStickChart.setHighlightPerDragEnabled(true);

        candleStickChart.setDrawBorders(true);

        candleStickChart.setBorderColor(getResources().getColor(R.color.black));

        YAxis yAxis = candleStickChart.getAxisLeft();
        YAxis rightAxis = candleStickChart.getAxisRight();
        yAxis.setDrawGridLines(true);
        rightAxis.setDrawGridLines(true);
        candleStickChart.requestDisallowInterceptTouchEvent(true);

        XAxis xAxis = candleStickChart.getXAxis();
        xAxis.setDrawGridLines(true);
        xAxis.setDrawLabels(true);
        rightAxis.setTextColor(Color.BLACK);
        yAxis.setDrawLabels(true);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setAvoidFirstLastClipping(true);

        Legend l = candleStickChart.getLegend();
        l.setEnabled(true);


        // create data

        ArrayList<CandleEntry> yValsCandleStick= new ArrayList<CandleEntry>();
        yValsCandleStick.add(new CandleEntry(0, 225.0F, 219.84F, 224.94F, 221.07F));

        for(int i = 0; i < this.candles.size(); ++i){
            BinanceCandle candle = this.candles.get(i);
            yValsCandleStick.add(new CandleEntry(i, (float)candle.getHigh(), (float)candle.getLow(), (float)candle.getOpen(), (float)candle.getClose()));
        }

        // set the data to the chart

        CandleDataSet set1 = new CandleDataSet(yValsCandleStick, this.coinName);
        set1.setColor(Color.rgb(80, 80, 80));
        set1.setShadowColor(getResources().getColor(R.color.colorPrimaryDark));
        set1.setShadowWidth(0.8f);
        set1.setDecreasingColor(getResources().getColor(R.color.red));
        set1.setDecreasingPaintStyle(Paint.Style.FILL);
        set1.setIncreasingColor(getResources().getColor(R.color.green));
        set1.setIncreasingPaintStyle(Paint.Style.FILL);
        set1.setNeutralColor(Color.LTGRAY);
        set1.setDrawValues(true);



        // create a data object with the datasets
        CandleData data = new CandleData(set1);


        // set data
        candleStickChart.setData(data);
        Description d = new Description();
        d.setText("Prices for " + this.coinName + " in the last 24h.");
        candleStickChart.setDescription(d);
        candleStickChart.setHovered(true);
        candleStickChart.setPinchZoom(true);
        candleStickChart.setDoubleTapToZoomEnabled(true);
        candleStickChart.getAxisLeft().setDrawTopYLabelEntry(true);

        yAxis.setAxisMinimum((float)this.minValue);
        yAxis.setAxisMaximum((float)this.maxValue);

        candleStickChart.invalidate();

    }

}
