package com.mycryptotrade.fragments.selectedcryptos;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mycryptotrade.R;
import com.mycryptotrade.cryptosselection.CryptoAssets;
import com.mycryptotrade.utils.Utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import okhttp3.internal.Util;

public class SelectedCryptosListAdapter extends RecyclerView.Adapter<SelectedCryptosListAdapter.ViewHolder>{

    private Context context;
    private ArrayList<String> currencies;

    public SelectedCryptosListAdapter(Context context){
        this.context = context;
    }

    @NonNull
    @Override
    public SelectedCryptosListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.crypto_card_without_checkbox_list, parent,false);
        return new SelectedCryptosListAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SelectedCryptosListAdapter.ViewHolder holder, int position) {
        String coin = this.currencies.get(position);
        holder.textView.setText(coin);

        CryptoAssets coinAsset = CryptoAssets.transformStringCoinToObject(coin);

        Drawable d = Utils.loadImage(coinAsset.getAssetName(), context);
        holder.imageView.setImageDrawable(d);
    }

    @Override
    public int getItemCount() {
        if(this.currencies != null)
            return this.currencies.size();
        else
            return 0;
    }

    public void setCurrencies(ArrayList<String> currencies) {
        this.currencies = currencies;
    }

    public ArrayList<String> getCurrencies() {
        return this.currencies;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.textView = (TextView) itemView.findViewById(R.id.crypto_card_without_checkbox_text_view);
            this.imageView = (ImageView) itemView.findViewById(R.id.card_image);
        }
    }
}
