package com.mycryptotrade.notifications;

import java.io.Serializable;

public class NotificationsTransfer implements Serializable {
    private String selectedCrypto;
    private String selectedOperation;
    private double coinValue;
    private boolean enable;

    public NotificationsTransfer(){}

    public NotificationsTransfer(String selectedCrypto, String selectedOperation, double coinValue) {
        this.selectedCrypto = selectedCrypto;
        this.selectedOperation = selectedOperation;
        this.coinValue = coinValue;
    }

    public String getSelectedCrypto() {
        return selectedCrypto;
    }

    public void setSelectedCrypto(String selectedCrypto) {
        this.selectedCrypto = selectedCrypto;
    }

    public String getSelectedOperation() {
        return selectedOperation;
    }

    public void setSelectedOperation(String selectedOperation) {
        this.selectedOperation = selectedOperation;
    }

    public double getCoinValue() {
        return coinValue;
    }

    public void setCoinValue(double coinValue) {
        this.coinValue = coinValue;
    }

    public boolean isEnable() {
        return enable;
    }

    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    @Override
    public String toString() {
        return "NotificationsTransfer{" +
                "selectedCrypto='" + selectedCrypto + '\'' +
                ", selectedOperation='" + selectedOperation + '\'' +
                ", coinValue=" + coinValue +
                ", enable=" + enable +
                '}';
    }
}
