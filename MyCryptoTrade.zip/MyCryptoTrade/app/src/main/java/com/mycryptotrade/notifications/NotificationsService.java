package com.mycryptotrade.notifications;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.loader.content.AsyncTaskLoader;

import com.mycryptotrade.AfterAuthenticationActivity;
import com.mycryptotrade.R;
import com.mycryptotrade.clients.BinanceClient;
import com.mycryptotrade.clients.RestClient;
import com.mycryptotrade.clients.RestClientImp;
import com.mycryptotrade.clients.firebase.Firestore;
import com.mycryptotrade.cryptos.BinanceCandle;
import com.mycryptotrade.cryptos.CurrentPriceSymbol;
import com.mycryptotrade.cryptos.MetricsTransfer;
import com.mycryptotrade.cryptos.SymbolStatistics;
import com.mycryptotrade.cryptosselection.CryptoAssets;

import java.util.Timer;
import java.util.TimerTask;

public class NotificationsService extends Service {
    private static final String CHANNEL_DEFAULT_IMPORTANCE = "NotificationService";
    private static final String TAG = "NotificationService";

    private Timer timer;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @SuppressLint("WrongConstant")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this, "service starting", Toast.LENGTH_SHORT).show();
        NotificationsTransfer transfer = (NotificationsTransfer)intent.getSerializableExtra("data");

        System.out.println("onStartCommand: " + transfer);

        timer = new Timer();
        timer.schedule(new MyTask(transfer), 0, 5000);

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.getTimer().cancel();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void createNotification(String selectedSymbol, double value, String msg){
        try{
            Intent notificationIntent = new Intent(this, AfterAuthenticationActivity.class);
            PendingIntent pendingIntent =
                    PendingIntent.getActivity(this, 0, notificationIntent, 0);

            NotificationCompat.Builder mBuilder =
                    new NotificationCompat.Builder(this, CHANNEL_DEFAULT_IMPORTANCE)
                            .setSmallIcon(R.drawable.logo)
                            .setContentTitle(selectedSymbol + " price changed!")
                            .setContentText(selectedSymbol + " " + msg.toLowerCase() + ".")
                            .setContentIntent(pendingIntent)
                            .setStyle(new NotificationCompat.BigTextStyle()
                                    .bigText(selectedSymbol + " " + msg.toLowerCase()
                                            + ". Current value: " + value))
                            .setAutoCancel(true);

            startForeground(1, mBuilder.build());

            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_DEFAULT_IMPORTANCE,
                    "Notification Service channel name",
                    NotificationManager.IMPORTANCE_HIGH);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(notificationChannel);


        }
        catch (Exception ex){
            Log.e(TAG, ex.getMessage());
        }
    }

    public Timer getTimer() {
        return timer;
    }

    public void setTimer(Timer timer) {
        this.timer = timer;
    }

    public class DoBackgroundTask extends AsyncTask<String, Integer, NotificationPriceTransfer> {

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected NotificationPriceTransfer doInBackground(String... s) {
            String selectedSymbol = s[0];
            String symbol = s[1];
            String operation = s[2];
            Double requestedPrice = Double.parseDouble(s[3]);
            Log.d(TAG, "doInBackground(): " + symbol + " " + operation + " " + requestedPrice);
            RestClient client = new RestClientImp();
            BinanceClient binanceClient = client.createBinanceClient();
            CurrentPriceSymbol price = binanceClient.getCurrentPrice(binanceClient.getCurrentPrice(symbol));
            return new NotificationPriceTransfer(requestedPrice, operation, selectedSymbol, price);
        }

        @Override
        protected void onProgressUpdate(Integer... values){
            Log.d(TAG, "onProgressUpdate: price fetched " + values[0]);
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        protected void onPostExecute(NotificationPriceTransfer c){
            Log.d(TAG, "onPostExecute: result " + c);
            String msgPriceChange = c.getOperationType() + " " + c.getRequestedPrice();
            if(c.getOperationType().equals("Price rise above")){
                if(c.getRequestedPrice() < c.getCurrentPriceSymbol().getPrice())
                    createNotification(c.getSelectedCrypto(), c.getCurrentPriceSymbol().getPrice(), msgPriceChange);
            }
            else{
                if(c.getRequestedPrice() > c.getCurrentPriceSymbol().getPrice())
                    createNotification(c.getSelectedCrypto(),c.getCurrentPriceSymbol().getPrice(), msgPriceChange);
            }
        }
    }

    class MyTask extends TimerTask {
        private NotificationsTransfer transfer;

        public MyTask(NotificationsTransfer transfer){
            this.transfer = transfer;
        }

        public void run() {
            if(transfer.isEnable()){
                String symbol = CryptoAssets.transformStringCoinToObject(transfer.getSelectedCrypto()).getAssetName() + "EUR";
                // get symbol price calling Binance API
                try {
                    new DoBackgroundTask().execute(transfer.getSelectedCrypto(), symbol,transfer.getSelectedOperation(), new Double(transfer.getCoinValue()).toString());
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage());
                }
                Intent localIntent = new Intent();
                localIntent.setAction("Notification");
                sendBroadcast(localIntent);
            }
            else{
                this.cancel();
                onDestroy();
                Log.e(TAG, "Service stopped");
            }
        }
    }

}
