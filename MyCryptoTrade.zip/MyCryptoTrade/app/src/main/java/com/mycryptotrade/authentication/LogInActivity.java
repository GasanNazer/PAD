package com.mycryptotrade.authentication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.auth.IdpResponse;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mycryptotrade.AfterAuthenticationActivity;
import com.mycryptotrade.R;

import java.util.Arrays;
import java.util.List;

public class LogInActivity extends AppCompatActivity {

    private final static String TAG = "LogInActivity";

    private static final int RC_SIGN_IN = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase_ui);

        if(FirebaseAuth.getInstance().getCurrentUser() != null){
            startActivity(new Intent(this, AfterAuthenticationActivity.class));
            this.finish();
        }
        createSignInIntent();
    }

    public void createSignInIntent() {
        // Choose authentication providers
        List<AuthUI.IdpConfig> providers = Arrays.asList(
                new AuthUI.IdpConfig.EmailBuilder().build(),
                //new AuthUI.IdpConfig.PhoneBuilder().build(),
                new AuthUI.IdpConfig.GoogleBuilder().build());
                //new AuthUI.IdpConfig.FacebookBuilder().build(),
                //new AuthUI.IdpConfig.TwitterBuilder().build());

        // Create and launch sign-in intent
        startActivityForResult(
                AuthUI.getInstance()
                        .createSignInIntentBuilder()
                        .setAvailableProviders(providers)
                        .setAlwaysShowSignInMethodScreen(true)
                        .setTheme(R.style.Theme_AppCompat_DayNight)
                        .setLogo(R.drawable.logo)
                        .setIsSmartLockEnabled(false)
                        .setAlwaysShowSignInMethodScreen(true)
                        .build(),
                RC_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            IdpResponse response = IdpResponse.fromResultIntent(data);

            if (resultCode == RESULT_OK) {
                // Successfully signed in
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                Intent homeActivity = new Intent(this, AfterAuthenticationActivity.class);
                //Intent homeActivity = new Intent(this, CryptoCurrenciesMetrics.class);
                homeActivity.putExtra("USER_NAME", user.getDisplayName());
                homeActivity.putExtra("USER_EMAIL", user.getEmail());
                homeActivity.putExtra("USER_UID", user.getUid());
                startActivity(homeActivity);

            } else {
                // Sign in failed.
                if(response == null){
                    Log.e(TAG, "onActivityResult: User cancelled the request");
                }
                else{
                    Log.e(TAG, "onActivityResult: " + response.getError().getMessage() + " Error code: " + response.getError().getErrorCode());
                    Toast.makeText(this, "Authentication failed.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
