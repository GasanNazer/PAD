package com.mycryptotrade.cryptos;

import com.mycryptotrade.cryptosselection.CryptoAssets;

import java.util.List;

public class MetricsTransfer {
    private CryptoAssets cryptoAsset;
    private SymbolStatistics symbolStatistics;
    private List<BinanceCandle> candles;

    public MetricsTransfer(CryptoAssets cryptoAsset, SymbolStatistics symbolStatistics, List<BinanceCandle> candles) {
        this.cryptoAsset = cryptoAsset;
        this.symbolStatistics = symbolStatistics;
        this.candles = candles;
    }

    public CryptoAssets getCryptoAsset() {
        return cryptoAsset;
    }

    public void setCryptoAsset(CryptoAssets cryptoAsset) {
        this.cryptoAsset = cryptoAsset;
    }

    public SymbolStatistics getSymbolStatistics() {
        return symbolStatistics;
    }

    public void setSymbolStatistics(SymbolStatistics symbolStatistics) {
        this.symbolStatistics = symbolStatistics;
    }

    public List<BinanceCandle> getCandles() {
        return candles;
    }

    public void setCandles(List<BinanceCandle> candles) {
        this.candles = candles;
    }

    @Override
    public String toString() {
        return "MetricsTransfer{" +
                "cryptoAsset=" + cryptoAsset +
                ", symbolStatistics=" + symbolStatistics +
                ", candles=" + candles +
                '}';
    }
}
