package com.mycryptotrade.fragments;

import android.annotation.SuppressLint;
import android.content.res.Configuration;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.mycryptotrade.R;
import com.mycryptotrade.clients.firebase.Firestore;
import com.mycryptotrade.cryptosselection.CryptoAssets;
import com.mycryptotrade.cryptosselection.CryptoAssetsLoader;
import com.mycryptotrade.cryptosselection.CryptoSelectionListAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FavouriteCryptoCurrenciesFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FavouriteCryptoCurrenciesFragment extends Fragment {

    private RecyclerView recyclerView;
    private CryptoSelectionListAdapter adapter;
    private int CRYPTOCURRENCIES_ASSETS_ID = 0;

    private final static String TAG = "FavouriteCryptoCurrenciesFragment";

    private CryptoCurrenciesAssetsLoaderCallbacks cryptoAssetsLoader = new CryptoCurrenciesAssetsLoaderCallbacks();

    public FavouriteCryptoCurrenciesFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FavouriteCryptoCurrenciesFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static FavouriteCryptoCurrenciesFragment newInstance(String param1, String param2) {
        FavouriteCryptoCurrenciesFragment fragment = new FavouriteCryptoCurrenciesFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        int orientation = getActivity().getResources().getConfiguration().orientation;

        View view;

        if(orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Inflate the layout for this fragment
            view = inflater.inflate(R.layout.fragment_favourite_list, container, false);
        }
        else{
            // orientation landscape
            view = inflater.inflate(R.layout.fragment_favourite_list_landscape, container, false);
        }

        this.recyclerView = (RecyclerView)view.findViewById(R.id.recycler_view_cryptos);
        this.adapter = new CryptoSelectionListAdapter(view.getContext());

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // for the loader of the Binance Assets
        LoaderManager loaderManager = LoaderManager.getInstance(this);
        if(loaderManager.getLoader(CRYPTOCURRENCIES_ASSETS_ID) != null){
            loaderManager.initLoader(CRYPTOCURRENCIES_ASSETS_ID,null, this.cryptoAssetsLoader);
        }

        Button saveFavouriteCryptos = (Button)view.findViewById(R.id.save_favourite_list_btn);
        saveFavouriteCryptos.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("LongLogTag")
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick saving favourites cryptocurrencies: " + adapter.getSelectedCryptos());
                Firestore dbClient = new Firestore();
                dbClient.saveCryptoCurrencyList(adapter.getSelectedCryptos());
                Toast.makeText(getContext(), "Your favourite list has been updated", Toast.LENGTH_LONG).show();
            }
        });

        getAssets();

        return view;
    }

    private void getAssets(){
        Bundle queryBundle = new Bundle();
        LoaderManager.getInstance(this).restartLoader(CRYPTOCURRENCIES_ASSETS_ID, queryBundle, this.cryptoAssetsLoader);
    }

    private void updateCryptosResultList(List<CryptoAssets> data){
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter.setCurrencies(new ArrayList<>(data));
        adapter.notifyDataSetChanged();
    }

    public class CryptoCurrenciesAssetsLoaderCallbacks implements LoaderManager.LoaderCallbacks<List<CryptoAssets>> {

        @NonNull
        @Override
        public Loader<List<CryptoAssets>> onCreateLoader(int id, @Nullable Bundle args) {
            return new CryptoAssetsLoader(getActivity());
        }

        @Override
        public void onLoadFinished(@NonNull Loader<List<CryptoAssets>> loader, List<CryptoAssets> data) {

            if (data.size() > 0) {
                updateCryptosResultList(data);
            }
            else {
                updateCryptosResultList(new ArrayList<CryptoAssets>());
            }
        }

        @Override
        public void onLoaderReset(@NonNull Loader<List<CryptoAssets>> loader) {
            loader.reset();
            adapter.notifyDataSetChanged();
        }
    }
}