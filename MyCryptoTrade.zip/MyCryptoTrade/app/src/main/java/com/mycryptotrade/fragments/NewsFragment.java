package com.mycryptotrade.fragments;

import android.content.res.Configuration;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.mycryptotrade.R;
import com.mycryptotrade.clients.firebase.Firestore;
import com.mycryptotrade.clients.firebase.MyCallback;
import com.mycryptotrade.cryptosselection.CryptoAssets;
import com.mycryptotrade.cryptosselection.CryptoAssetsLoader;
import com.mycryptotrade.cryptosselection.CryptoSelectionListAdapter;
import com.mycryptotrade.twitter.TweetInformation;
import com.mycryptotrade.twitter.TwitterTweetsAdapter;
import com.mycryptotrade.twitter.TwitterTweetsLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NewsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewsFragment extends Fragment {

    private RecyclerView recyclerView;
    private TwitterTweetsAdapter adapter;
    private int TWITTER_ID = 0;

    private final static String TAG = "NewsFragment";

    private NewsFragment.TwitterTweetsLoaderCallbacks twitterTweetsLoaderCallbacks = new TwitterTweetsLoaderCallbacks();

    public NewsFragment() {
        // Required empty public constructor
    }

    public static NewsFragment newInstance() {
        NewsFragment fragment = new NewsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        int orientation = getActivity().getResources().getConfiguration().orientation;

        View view;

        if(orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Inflate the layout for this fragment
            view = inflater.inflate(R.layout.fragment_news, container, false);
        }
        else{
            // orientation landscape
            view = inflater.inflate(R.layout.fragment_news_landscape, container, false);
        }

        this.recyclerView = (RecyclerView)view.findViewById(R.id.news_recycler_view);
        this.adapter = new TwitterTweetsAdapter(view.getContext());

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // for the loader of the Binance Assets
        LoaderManager loaderManager = LoaderManager.getInstance(this);
        if(loaderManager.getLoader(TWITTER_ID) != null){
            loaderManager.initLoader(TWITTER_ID,null, this.twitterTweetsLoaderCallbacks);
        }

        getTweets();

        return view;
    }

    private void getTweets(){
        Bundle queryBundle = new Bundle();
        LoaderManager.getInstance(this).restartLoader(TWITTER_ID, queryBundle, this.twitterTweetsLoaderCallbacks);
    }

    private void updateTweetsResultList(List<TweetInformation> data){
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter.setTweets(new ArrayList<>(data));
        adapter.notifyDataSetChanged();
    }


    public class TwitterTweetsLoaderCallbacks implements LoaderManager.LoaderCallbacks<List<TweetInformation>> {

        @NonNull
        @Override
        public Loader<List<TweetInformation>> onCreateLoader(int id, @Nullable Bundle args) {
            Toast.makeText(getContext(), "Loading...", Toast.LENGTH_LONG).show();
            return new TwitterTweetsLoader(getActivity());
        }

        @Override
        public void onLoadFinished(@NonNull Loader<List<TweetInformation>> loader, List<TweetInformation> data) {

            if (data.size() > 0) {
                updateTweetsResultList(data);
            }
            else {
                updateTweetsResultList(new ArrayList<TweetInformation>());
                Toast.makeText(getContext(), "Your favourite list is empty.", Toast.LENGTH_LONG).show();
            }
        }

        @Override
        public void onLoaderReset(@NonNull Loader<List<TweetInformation>> loader) {
            loader.reset();
            adapter.notifyDataSetChanged();
        }
    }

}