package com.mycryptotrade.fragments;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseUser;
import com.mycryptotrade.R;
import com.mycryptotrade.clients.firebase.Firestore;
import com.mycryptotrade.clients.firebase.MyCallback;
import com.mycryptotrade.fragments.selectedcryptos.SelectedCryptosListAdapter;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private static final String ARG_PARAM1 = "user_name";

    private RecyclerView recyclerView;
    private SelectedCryptosListAdapter adapter;

    private String mParam1;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(FirebaseUser user) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, user.getDisplayName());
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        int orientation = getActivity().getResources().getConfiguration().orientation;

        View view;

        if(orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Inflate the layout for this fragment
            view = inflater.inflate(R.layout.fragment_home, container, false);
        }
        else{
            // orientation landscape
            view = inflater.inflate(R.layout.fragment_home_landscape, container, false);
        }

        TextView textViewName = (TextView)view.findViewById(R.id.home_textview_name);
        this.recyclerView = (RecyclerView)view.findViewById(R.id.recycler_view_cryptos);
        this.adapter = new SelectedCryptosListAdapter(view.getContext());

        textViewName.setText("Hello " + mParam1);

        updateCryptosResultList(view.getContext(), view);

        return view;
    }

    void updateCryptosResultList(Context context, View view){
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));

        Firestore dbClient = new Firestore();
        dbClient.getCurrencies(new MyCallback() {
            @Override
            public void onCallback(ArrayList<String> result) {
                if(result.size() > 0) {
                    adapter.setCurrencies(result);
                    adapter.notifyDataSetChanged();
                }
                else{
                    TextView message = (TextView) view.findViewById(R.id.home_favourite_list_message);
                    message.setText("There are no cryptocurrencies in your favourite list.");
                }
            }
        });

    }
}