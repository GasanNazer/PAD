package com.mycryptotrade.clients;

public interface RestClient {

	public BinanceClient createBinanceClient();
	public TwitterClient createTwitterClient();
}
