package com.mycryptotrade.twitter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mycryptotrade.R;

import java.util.ArrayList;

public class TwitterTweetsAdapter extends RecyclerView.Adapter<TwitterTweetsAdapter.ViewHolder>{

    private Context context;
    private ArrayList<TweetInformation> tweets;

    public TwitterTweetsAdapter(Context context){
        this.context = context;
    }

    @NonNull
    @Override
    public TwitterTweetsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.crypto_news_card_list, parent,false);
        return new TwitterTweetsAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TwitterTweetsAdapter.ViewHolder holder, int position) {
        TweetInformation tweetInformation = this.tweets.get(position);
        TwitterUser user = tweetInformation.getUser();
        Tweet tweet = tweetInformation.getTweet();

        String author = user.getName();
        if(user.getName().length() < 25)
            author = user.getName() + " @" + user.getUsername();

        String text = tweet.getText();
        if(text.length() > 150){
            text = text.substring(0, 150) + "...";
        }

        holder.textViewAuthor.setText(author);
        holder.textViewText.setText(text);
        holder.imageView.setImageResource(R.drawable.fui_ic_twitter_bird_white_24dp);
    }

    @Override
    public int getItemCount() {
        if(this.tweets != null)
            return this.tweets.size();
        else
            return 0;
    }

    public ArrayList<TweetInformation> getTweets() {
        return tweets;
    }

    public void setTweets(ArrayList<TweetInformation> tweets) {
        this.tweets = tweets;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewAuthor;
        TextView textViewText;
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.textViewAuthor = (TextView) itemView.findViewById(R.id.metrics_coin_name);
            this.textViewText = (TextView) itemView.findViewById(R.id.metrics_coin_highest_24h);
            this.imageView = (ImageView) itemView.findViewById(R.id.news_card_image);
        }
    }
}
