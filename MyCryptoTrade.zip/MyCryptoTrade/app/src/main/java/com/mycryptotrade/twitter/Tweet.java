package com.mycryptotrade.twitter;

public class Tweet {
    private Long author_id;
    private Long id;
    private String text;

    public Tweet(Long author_id, Long id, String text) {
        this.author_id = author_id;
        this.id = id;
        this.text = text;
    }

    public Long getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(Long author_id) {
        this.author_id = author_id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "Tweet{" +
                "author_id=" + author_id +
                ", id=" + id +
                ", text='" + text + '\'' +
                '}';
    }
}
