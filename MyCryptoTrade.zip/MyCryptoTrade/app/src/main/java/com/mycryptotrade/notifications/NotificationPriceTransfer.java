package com.mycryptotrade.notifications;

import com.mycryptotrade.cryptos.CurrentPriceSymbol;

public class NotificationPriceTransfer {
    private Double requestedPrice;
    private String operationType;
    private String selectedCrypto;
    private CurrentPriceSymbol currentPriceSymbol;

    public NotificationPriceTransfer(Double requestedPrice, String operationType, String selectedCrypto, CurrentPriceSymbol currentPriceSymbol) {
        this.requestedPrice = requestedPrice;
        this.operationType = operationType;
        this.selectedCrypto = selectedCrypto;
        this.currentPriceSymbol = currentPriceSymbol;
    }

    public Double getRequestedPrice() {
        return requestedPrice;
    }

    public void setRequestedPrice(Double requestedPrice) {
        this.requestedPrice = requestedPrice;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getSelectedCrypto() {
        return selectedCrypto;
    }

    public void setSelectedCrypto(String selectedCrypto) {
        this.selectedCrypto = selectedCrypto;
    }

    public CurrentPriceSymbol getCurrentPriceSymbol() {
        return currentPriceSymbol;
    }

    public void setCurrentPriceSymbol(CurrentPriceSymbol currentPriceSymbol) {
        this.currentPriceSymbol = currentPriceSymbol;
    }

    @Override
    public String toString() {
        return "NotificationPriceTransfer{" +
                "requestedPrice=" + requestedPrice +
                ", operationType='" + operationType + '\'' +
                ", selectedCrypto='" + selectedCrypto + '\'' +
                ", currentPriceSymbol=" + currentPriceSymbol +
                '}';
    }
}
