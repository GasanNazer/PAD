package com.mycryptotrade.clients;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.IOException;
import java.util.concurrent.CompletableFuture;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@RequiresApi(api = Build.VERSION_CODES.N)
class CallbackFuture extends CompletableFuture<Response> implements Callback {

	@Override
	public void onFailure(Call arg0, IOException arg1) {
		super.completeExceptionally(arg1);
	}
	@Override
	public void onResponse(Call arg0, Response arg1) throws IOException {
		 super.complete(arg1);
	}
}