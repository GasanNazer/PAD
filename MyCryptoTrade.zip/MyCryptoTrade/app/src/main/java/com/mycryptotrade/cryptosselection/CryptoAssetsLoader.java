package com.mycryptotrade.cryptosselection;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.loader.content.AsyncTaskLoader;

import com.mycryptotrade.clients.BinanceClient;
import com.mycryptotrade.clients.RestClient;
import com.mycryptotrade.clients.RestClientImp;
import com.mycryptotrade.cryptos.SymbolStatistics;

import java.util.List;

public class CryptoAssetsLoader extends AsyncTaskLoader<List<CryptoAssets>> {
    private BinanceClient binanceClient;

    public CryptoAssetsLoader(@NonNull Context context) {
        super(context);

        RestClient client = new RestClientImp();
        this.binanceClient = client.createBinanceClient();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public List<CryptoAssets> loadInBackground() {
        return this.binanceClient.getCryptoAssets(this.binanceClient.getCurrenciesAssets());
    }

    public void onStartLoading(){
        this.forceLoad();
    }
}
