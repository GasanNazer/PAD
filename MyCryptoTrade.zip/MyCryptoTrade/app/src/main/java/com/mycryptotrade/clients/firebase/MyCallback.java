package com.mycryptotrade.clients.firebase;

import java.util.ArrayList;
import java.util.List;

public interface MyCallback {
    void onCallback(ArrayList<String> cryptosList);
}
