package com.mycryptotrade.twitter;

public class TweetInformation {
    private Tweet tweet;
    private TwitterUser user;

    public TweetInformation(Tweet tweet, TwitterUser user) {
        this.tweet = tweet;
        this.user = user;
    }

    public Tweet getTweet() {
        return tweet;
    }

    public void setTweet(Tweet tweet) {
        this.tweet = tweet;
    }

    public TwitterUser getUser() {
        return user;
    }

    public void setUser(TwitterUser user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "TweetInformation{" +
                "tweet=" + tweet +
                ", user=" + user +
                '}';
    }
}
