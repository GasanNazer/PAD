package com.mycryptotrade.fragments;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.mycryptotrade.AfterAuthenticationActivity;
import com.mycryptotrade.R;
import com.mycryptotrade.clients.firebase.Firestore;
import com.mycryptotrade.clients.firebase.MyCallback;
import com.mycryptotrade.notifications.NotificationsService;
import com.mycryptotrade.notifications.NotificationsTransfer;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class NotificationsFragment extends Fragment {

    private final static String TAG = "NotificationsFragment";


    public NotificationsFragment() {
        // Required empty public constructor
    }

    public static NotificationsFragment newInstance() {
        NotificationsFragment fragment = new NotificationsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        int orientation = getActivity().getResources().getConfiguration().orientation;

        View view;

        if(orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Inflate the layout for this fragment
            view = inflater.inflate(R.layout.fragment_notifications, container, false);
        }
        else{
            // orientation landscape
            view = inflater.inflate(R.layout.fragment_notifications_landscape, container, false);
        }

        // Create Alert Type Spinner
        Spinner alertTypeSpinner = (Spinner)view.findViewById(R.id.notifications_alert_type_spinner);

        ArrayList<String> types = new ArrayList<>();
        types.add("Price rise above");
        types.add("Price drops to");

        ArrayAdapter<String> alertTypeAdapter = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_list_item_1 , types);
        alertTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        alertTypeSpinner.setAdapter(alertTypeAdapter);

        // Create Select CryptoCurrencies Spinner
        Spinner notificationsCryptosSpinner = (Spinner)view.findViewById(R.id.notifications_cryptos_spinner);

        Firestore dbClient = new Firestore();
        dbClient.getCurrencies(new MyCallback() {
            @Override
            public void onCallback(ArrayList<String> result) {
                if(result.size() > 0) {
                    ArrayList<String> cryptos = new ArrayList<>();

                    for(String coin : result)
                        cryptos.add(coin);

                    ArrayAdapter<String> cryptosAdapter = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_list_item_1 , cryptos);
                    cryptosAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    notificationsCryptosSpinner.setAdapter(cryptosAdapter);
                }
                else{
                    Log.d(TAG,"Favourite list is empty.");
                    Toast.makeText(getContext(), "Your favourite list is empty.", Toast.LENGTH_LONG).show();
                }
            }
        });

        EditText valueNumber = (EditText) view.findViewById(R.id.notifications_value_number);

        Button createNotificationButton = (Button) view.findViewById(R.id.notifications_create_button);

        createNotificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NotificationsTransfer notificationsTransfer = new NotificationsTransfer(
                        notificationsCryptosSpinner.getSelectedItem().toString(),
                        alertTypeSpinner.getSelectedItem().toString(),
                        Double.parseDouble(valueNumber.getText().toString())
                );

                notificationsTransfer.setEnable(true);

                System.out.println("Create: " + notificationsCryptosSpinner);

                creteService(notificationsTransfer);
            }
        });

        Button deleteNotificationButton = (Button) view.findViewById(R.id.notifications_delete_button);

        deleteNotificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NotificationsTransfer notificationsTransfer = new NotificationsTransfer(
                        notificationsCryptosSpinner.getSelectedItem().toString(),
                        alertTypeSpinner.getSelectedItem().toString(),
                        Double.parseDouble(valueNumber.getText().toString())
                );

                notificationsTransfer.setEnable(false);

                //creteService(notificationsTransfer);
                deleteService(notificationsTransfer);
            }
        });


        // broadcast notifications
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("Notification");

        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Log.e(TAG, "Broadcast fragment:");
            }
        };

        getContext().registerReceiver(broadcastReceiver, intentFilter);

        return view;
    }

    private void creteService(NotificationsTransfer notificationsCryptosSpinner){
        ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.FOREGROUND_SERVICE}, PackageManager.PERMISSION_GRANTED);

        Intent intentService = new Intent(getActivity(), NotificationsService.class);
        intentService.putExtra("data", notificationsCryptosSpinner);
        String serviceName = notificationsCryptosSpinner.getSelectedCrypto()
                + notificationsCryptosSpinner.getSelectedOperation()
                + notificationsCryptosSpinner.getCoinValue();
        ((AfterAuthenticationActivity)getActivity()).setRunningService(
                serviceName,
                intentService
        );
        getActivity().startService(intentService);
    }

    private void deleteService(NotificationsTransfer notificationsCryptosSpinner){
        String serviceName = notificationsCryptosSpinner.getSelectedCrypto()
                + notificationsCryptosSpinner.getSelectedOperation()
                + notificationsCryptosSpinner.getCoinValue();

        Intent service = ((AfterAuthenticationActivity)getActivity()).getRunningService(
                serviceName);
        System.out.println("Hashmap: " + ((AfterAuthenticationActivity)getActivity()).getRunningServices());
        ((AfterAuthenticationActivity)getActivity()).removeRunningService(
                serviceName);

        Log.d(TAG,"Stopped service: " + serviceName);
        if(service != null)
            getActivity().stopService(service);
    }
}