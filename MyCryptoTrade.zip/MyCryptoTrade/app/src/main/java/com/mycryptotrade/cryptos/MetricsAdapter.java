package com.mycryptotrade.cryptos;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mycryptotrade.R;
import com.mycryptotrade.cryptosselection.CryptoAssets;

import java.util.ArrayList;

public class MetricsAdapter extends RecyclerView.Adapter<MetricsAdapter.ViewHolder>{

    private Context context;
    private ArrayList<MetricsTransfer> coins;

    public MetricsAdapter(Context context){
        this.context = context;
    }

    @NonNull
    @Override
    public MetricsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.crypto_metrics_card_list, parent,false);
        return new MetricsAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MetricsAdapter.ViewHolder holder, int position) {
        MetricsTransfer coin = this.coins.get(position);
        CryptoAssets coinName = coin.getCryptoAsset();
        SymbolStatistics statistics = coin.getSymbolStatistics();
        holder.metrics_coin_name.setText(CryptoAssets.transformCoinObjectToSting(coinName));
        holder.metrics_coin_highest_24h.setText(String.format("%,.2f", statistics.getHighPrice()) + "€");
        holder.metrics_coin_lowest_24h.setText(String.format("%,.2f", statistics.getLowPrice()) + "€");
        holder.metrics_volume_24h.setText(String.format("%,.2f", statistics.getQuoteVolume()) + "€");

        Double mean_value_last_24H = 0.0;

        for(BinanceCandle candle: coin.getCandles()){
            mean_value_last_24H += candle.getHigh() + candle.getLow();
        }

        mean_value_last_24H /= 2 * coin.getCandles().size(); // sum(high hour + low hour) / 2 * totalCandles, 2 comes as we make mean on 2 values high and low

        holder.metrics_avg_24h_value.setText(String.format("%,.2f", mean_value_last_24H) + "€");
        holder.metrics_current_price_value.setText(statistics.getLastPrice() + "€");

        holder.metrics_chart.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, ChartActivity.class);
                i.putExtra("data", new ArrayList<BinanceCandle>(coin.getCandles()));
                i.putExtra("coinName", CryptoAssets.transformCoinObjectToSting(coinName));
                i.putExtra("min", statistics.getLowPrice());
                i.putExtra("max", statistics.getHighPrice());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        if(this.coins != null)
            return this.coins.size();
        else
            return 0;
    }

    public ArrayList<MetricsTransfer> getCoins() {
        return coins;
    }

    public void setCoins(ArrayList<MetricsTransfer> coins) {
        this.coins = coins;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView metrics_coin_name;
        TextView metrics_coin_highest_24h;
        TextView metrics_coin_lowest_24h;
        TextView metrics_volume_24h;
        TextView metrics_avg_24h_value;
        TextView metrics_current_price_value;
        Button metrics_chart;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.metrics_coin_name = (TextView) itemView.findViewById(R.id.metrics_coin_name);
            this.metrics_coin_highest_24h = (TextView) itemView.findViewById(R.id.metrics_coin_highest_24h);
            this.metrics_coin_lowest_24h = (TextView) itemView.findViewById(R.id.metrics_coin_lowest_24h);
            this.metrics_volume_24h = (TextView) itemView.findViewById(R.id.metrics_volume_24h);
            this.metrics_avg_24h_value = (TextView) itemView.findViewById(R.id.metrics_avg_24h_value);
            this.metrics_current_price_value = (TextView) itemView.findViewById(R.id.metrics_current_price_value);
            this.metrics_chart = (Button) itemView.findViewById(R.id.metrics_chart);
        }
    }
}
