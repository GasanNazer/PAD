package com.mycryptotrade.clients;

public class RestClientImp implements RestClient{

	@Override
	public BinanceClient createBinanceClient() {
		return new BinanceClient();
	}

	@Override
	public TwitterClient createTwitterClient() {
		return new TwitterClient();
	}

}
