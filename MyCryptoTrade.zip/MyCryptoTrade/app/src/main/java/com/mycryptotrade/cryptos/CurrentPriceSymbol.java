package com.mycryptotrade.cryptos;

public class CurrentPriceSymbol {
    private String symbol;
    private Double price;

    public CurrentPriceSymbol(){};

    public CurrentPriceSymbol(String symbol, Double price) {
        this.symbol = symbol;
        this.price = price;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "CurrentPriceSymbol{" +
                "symbol='" + symbol + '\'' +
                ", price=" + price +
                '}';
    }
}
