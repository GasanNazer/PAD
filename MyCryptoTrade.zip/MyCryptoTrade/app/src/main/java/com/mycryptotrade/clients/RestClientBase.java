package com.mycryptotrade.clients;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class RestClientBase {

	private static final String TAG = "RestClientBase";

	private String result = null;
	private String baseUrl;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String makeSynchronousCall(String url) {
		OkHttpClient client = new OkHttpClient();

		Request request = new Request.Builder().url(url).build();

		Call call = client.newCall(request);
		Response response = null;
		try {
			response = call.execute();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error during execution of the call.");
		}
		String responseData = null;
		try {
			responseData = response.body().string();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Body cannot be transformed into string.");
		}

		return responseData;
	}

	@RequiresApi(api = Build.VERSION_CODES.N)
	public String makeAsynchronousCall(String url) {
		CallbackFuture future = new CallbackFuture();

		OkHttpClient client = new OkHttpClient();

		Request request = new Request.Builder().url(url).build();

		client.newCall(request).enqueue(future);

		Response response = null;

		try {
			response = future.get();
		} catch (InterruptedException | ExecutionException ex) {
			Log.e(TAG, "makeAsynchronousCall: " + ex);
		}
		
		String result = null;
		
		try {
			result = response.body().string();
		} catch (IOException ex) {
			Log.e(TAG, "makeAsynchronousCall: " + ex);
		}

		return result;
	}

	@RequiresApi(api = Build.VERSION_CODES.N)
	public String makeAsynchronousCallSecured(String url, String apiKeyName, String apiKeyValue) {
		CallbackFuture future = new CallbackFuture();

		OkHttpClient client = new OkHttpClient();

		Request request = new Request.Builder().url(url)
				.addHeader(apiKeyName, apiKeyValue)
				.build();

		client.newCall(request).enqueue(future);

		Response response = null;

		try {
			response = future.get();
		} catch (InterruptedException | ExecutionException ex) {
			Log.e(TAG, "makeAsynchronousCall: " + ex);
		}

		String result = null;

		try {
			result = response.body().string();
		} catch (Exception ex) {
			Log.e(TAG, "makeAsynchronousCall: " + ex);
		}

		return result;
	}

	public String constructUrl(String url) {
		return this.baseUrl + url;
	}

}
