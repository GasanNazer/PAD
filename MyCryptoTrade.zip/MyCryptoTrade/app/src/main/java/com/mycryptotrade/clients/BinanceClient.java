package com.mycryptotrade.clients;

import android.media.MediaDrm;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mycryptotrade.cryptos.BinanceCandle;
import com.mycryptotrade.cryptos.CurrentPriceSymbol;
import com.mycryptotrade.cryptos.SymbolStatistics;
import com.mycryptotrade.cryptosselection.CryptoAssets;
import com.mycryptotrade.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BinanceClient extends RestClientBase {
	private static final String TAG = "BinanceClient";

	public static final String BASE_URL = "https://api.binance.com";
	public static final String SERVER_TIME_ENDPOINT = "/api/v3/time";
	public static final String PRICE_CHANGE_24_HOURS_SYMBOL = "/api/v3/ticker/24hr?symbol=";
	public static final String CANDLES_ENDPOINT = "/api/v3/klines";
	public static final String ALL_ASSETS = "/sapi/v1/margin/allAssets";
	public static final String CURRENT_PRICE = "/api/v3/ticker/price";
	private static final String API_KEY_NAME = "X-MBX-APIKEY";
	// not the best way to give this parameter in the feature it should be given as
	// an environment variable
	private static final String API_KEY_VALUE = "FBcrXBU6NiZmZLh016xDXwBbKBOrQ2SPaS3STYWswwKdybEOkztbl7uUHqeYcrX9";
	
	public BinanceClient() {
		this.setBaseUrl(BASE_URL);
	}
	
	@RequiresApi(api = Build.VERSION_CODES.N)
	public Long getServerTime() {
		String result = this.makeAsynchronousCall(this.constructUrl(SERVER_TIME_ENDPOINT));
		Long serverTime = -1L;

		try {
			JSONObject jsonObject = new JSONObject(result);
			serverTime = (Long) jsonObject.get("serverTime");
		}
		catch (JSONException ex){
			Log.e(TAG, "getServerTime: " + ex);
		}
		
		return serverTime;
	}
	
	@RequiresApi(api = Build.VERSION_CODES.N)
	public JSONObject getPriceChange24h(String symbol) {
		String result = this.makeAsynchronousCall(this.constructUrl(PRICE_CHANGE_24_HOURS_SYMBOL + symbol));
		JSONObject jsonObject = null;

		try {
			jsonObject = new JSONObject(result);
		}
		catch (JSONException ex){
			Log.e(TAG, "getPriceChange24h: " + ex);
		}
		
		return jsonObject;
	}

	@RequiresApi(api = Build.VERSION_CODES.N)
	public JSONArray getCurrenciesAssets() {
		String result = this.makeAsynchronousCallSecured(
				this.constructUrl(ALL_ASSETS),
				API_KEY_NAME,
				API_KEY_VALUE);

		JSONArray jsonObject = null;

		try {
			jsonObject = new JSONArray(result);
		}
		catch (JSONException ex){
			Log.e(TAG, "getCurrenciesAssets: " + ex);
		}

		return jsonObject;
	}

	public SymbolStatistics fromJsonResponse(JSONObject jsonObject){
		try{
			SymbolStatistics symbol = new SymbolStatistics(
					jsonObject.getString("symbol"),
					jsonObject.getDouble("priceChange"),
					jsonObject.getDouble("priceChangePercent"),
					jsonObject.getDouble("weightedAvgPrice"),
					jsonObject.getDouble("prevClosePrice"),
					jsonObject.getDouble("lastPrice"),
					jsonObject.getDouble("lastQty"),
					jsonObject.getDouble("bidPrice"),
					jsonObject.getDouble("bidQty"),
					jsonObject.getDouble("askPrice"),
					jsonObject.getDouble("askQty"),
					jsonObject.getDouble("openPrice"),
					jsonObject.getDouble("highPrice"),
					jsonObject.getDouble("lowPrice"),
					jsonObject.getDouble("volume"),
					jsonObject.getDouble("quoteVolume"),
					jsonObject.getInt("openTime"),
					jsonObject.getInt("closeTime"),
					jsonObject.getInt("firstId"),
					jsonObject.getInt("lastId"),
					jsonObject.getInt("count")
			);

			return symbol;
		}
		catch(Exception ex){
			Log.e(TAG,"fromJsonResponse: " + ex.getMessage());
		}

		return null;
	}

	public List<CryptoAssets> getCryptoAssets(JSONArray jsonArr){
		List<CryptoAssets> itemsFetched = new ArrayList<>();

		try{

			for (int i = 0; i < jsonArr.length(); i++)
			{
				JSONObject jsonObj = jsonArr.getJSONObject(i);
				CryptoAssets coin = new CryptoAssets(
						jsonObj.getString("assetName"),
						jsonObj.getString("assetFullName"));
				itemsFetched.add(coin);
			}
		}
		catch(Exception ex){
			Log.e(TAG,"getCryptoAssets: " + ex.getMessage());
		}

		return itemsFetched;
	}

	@RequiresApi(api = Build.VERSION_CODES.N)
	public JSONArray getCandlesInterval1HForLast24H(String symbol) {
		String query = "?symbol=" + symbol +
				"&interval=1h" +
				"&startTime=" + Utils.convertDateToTimestamp(Utils.getDateNdaysFromNow(1)) +
				"&endTime=" + + Utils.convertDateToTimestamp(Utils.getDateNdaysFromNow(0));

		Log.d(TAG, "getCandlesInterval1HForLast24H(): " + query);

		String result = this.makeAsynchronousCall(
				this.constructUrl(CANDLES_ENDPOINT + query));

		JSONArray jsonObject = null;

		try {
			jsonObject = new JSONArray(result);
		}
		catch (JSONException ex){
			Log.e(TAG, "getCandlesInterval1HForLast24H: " + ex);
		}

		return jsonObject;
	}

	public List<BinanceCandle> getCandles(JSONArray jsonArr){
		List<BinanceCandle> itemsFetched = new ArrayList<>();

		try {
			for(int i = 0; i < jsonArr.length(); i++){
				JSONArray candle = jsonArr.getJSONArray(i);
				BinanceCandle c = new BinanceCandle(
						candle.getLong(0),
						candle.getDouble(1),
						candle.getDouble(2),
						candle.getDouble(3),
						candle.getDouble(4),
						candle.getDouble(5),
						candle.getDouble(6),
						candle.getDouble(7),
						candle.getInt(8),
						candle.getDouble(9),
						candle.getDouble(10),
						candle.getDouble(11)
				);

				itemsFetched.add(c);
			}

		} catch (JSONException ex) {
			Log.e(TAG,"getCandles: " + ex.getMessage());
		}

		return itemsFetched;
	}

	@RequiresApi(api = Build.VERSION_CODES.N)
	public JSONObject getCurrentPrice(String symbol) {
		String query = "?symbol=" + symbol;
		String result = this.makeAsynchronousCall(this.constructUrl(CURRENT_PRICE + query));

		JSONObject jsonObject = null;

		try {
			jsonObject = new JSONObject(result);
		}
		catch (JSONException ex){
			Log.e(TAG, "getCurrentPrice: " + ex);
		}

		return jsonObject;
	}

	public CurrentPriceSymbol getCurrentPrice(JSONObject jsonObject){

		try {
			CurrentPriceSymbol result = new CurrentPriceSymbol(
					jsonObject.getString("symbol"),
					jsonObject.getDouble("price")
			);

			return result;
		} catch (JSONException ex) {
			Log.e(TAG,"getCandles: " + ex.getMessage());
		}

		return new CurrentPriceSymbol();
	}


}
