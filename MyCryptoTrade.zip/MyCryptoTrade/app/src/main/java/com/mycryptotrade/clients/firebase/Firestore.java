package com.mycryptotrade.clients.firebase;

import android.util.Log;
import androidx.annotation.NonNull;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.mycryptotrade.cryptosselection.CryptoAssets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Firestore {

    private final static String TAG = "Firestore";

    private CollectionReference usersCollection = FirebaseFirestore.getInstance().collection("users");
    private final static String FAVOURITE_CRYPTO_CURRENCIES = "favourite_crypto_currencies";

    private ArrayList<String> favourite_crypto_currencies;

    public void saveCryptoCurrencyList(String email, ArrayList<String> currencies){

        Map<String, Object> dataToSave = new HashMap<>();
        dataToSave.put(FAVOURITE_CRYPTO_CURRENCIES, currencies);

        DocumentReference mDocRef = usersCollection.document(email);

        mDocRef.set(dataToSave).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Log.d(TAG, "onComplete: Data saved");
                }
                else{
                    Log.e(TAG, "onComplete: Data is not saved", task.getException());
                }
            }
        });
    }

    private void fetchCryptoCurrencyList(String email){
        DocumentReference mDocRef = usersCollection.document(email);

        mDocRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    Log.d(TAG, "onComplete: Data was fetched");
                    DocumentSnapshot documentSnapshot = task.getResult();
                    if(documentSnapshot.exists()){
                        favourite_crypto_currencies = (ArrayList<String>)documentSnapshot.get(FAVOURITE_CRYPTO_CURRENCIES);
                        Log.d(TAG, "Crypto currencies list: " + favourite_crypto_currencies);
                    }
                    else{
                        Log.e(TAG, "onComplete: Document empty", task.getException());
                    }
                }
                else{
                    Log.e(TAG, "onComplete: Data was not fetched", task.getException());
                }
            }
        });

    }

    public void saveCryptoCurrencyList(ArrayList<CryptoAssets> currencies){
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        ArrayList<String> transformedCurrencies = transformAssetsToString(currencies);
        this.saveCryptoCurrencyList(user.getEmail(), transformedCurrencies);
    }

    private ArrayList<String> transformAssetsToString(ArrayList<CryptoAssets> currencies) {
        ArrayList<String> coinsToString = new ArrayList<>();

        for(CryptoAssets coin: currencies)
            coinsToString.add(CryptoAssets.transformCoinObjectToSting(coin));

        return coinsToString;
    }

    public void getCurrencies(MyCallback myCallback){
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        DocumentReference mDocRef = usersCollection.document(user.getEmail());

        mDocRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    Log.d(TAG, "onComplete: Data was fetched");
                    DocumentSnapshot documentSnapshot = task.getResult();
                    if(documentSnapshot.exists()){
                        ArrayList<String> data = (ArrayList<String>)documentSnapshot.get(FAVOURITE_CRYPTO_CURRENCIES);
                        Log.d(TAG, "Crypto currencies list: " + data);
                        myCallback.onCallback(data);
                    }
                    else{
                        Log.e(TAG, "onComplete: Document empty", task.getException());
                    }
                }
                else{
                    Log.e(TAG, "onComplete: Data was not fetched", task.getException());
                }
            }
        });
    }

    public ArrayList<CryptoAssets> getFavouriteCryptoCurrenciesSynchronous() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        DocumentReference mDocRef = usersCollection.document(user.getEmail());

        Task<DocumentSnapshot> task = mDocRef.get();
        DocumentSnapshot documentSnapshot = null;
        try{
            documentSnapshot = Tasks.await(task);}
        catch (Exception ex){

        }
        ArrayList<String> data = (ArrayList<String>)documentSnapshot.get(FAVOURITE_CRYPTO_CURRENCIES);
        return CryptoAssets.transformArrayStringCoinToObjects(data);
    }
}
