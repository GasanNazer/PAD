package com.mycryptotrade.cryptosselection;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Objects;

public class CryptoAssets {

    private String assetName;
    private String assetFullName;
    private Boolean isBorrowable;
    private Boolean isMortgageable;
    private Long userMinBorrow;
    private Long userMinRepay;

    public CryptoAssets(String assetName, String assetFullName) {
        this.assetName = assetName;
        this.assetFullName = assetFullName;
    }

    public CryptoAssets(String assetName, String assetFullName, Boolean isBorrowable, Boolean isMortgageable, Long userMinBorrow, Long userMinRepay) {
        this.assetName = assetName;
        this.assetFullName = assetFullName;
        this.isBorrowable = isBorrowable;
        this.isMortgageable = isMortgageable;
        this.userMinBorrow = userMinBorrow;
        this.userMinRepay = userMinRepay;
    }

    public String getAssetName() {
        return assetName;
    }

    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }

    public String getAssetFullName() {
        return assetFullName;
    }

    public void setAssetFullName(String assetFullName) {
        this.assetFullName = assetFullName;
    }

    public Boolean getBorrowable() {
        return isBorrowable;
    }

    public void setBorrowable(Boolean borrowable) {
        isBorrowable = borrowable;
    }

    public Boolean getMortgageable() {
        return isMortgageable;
    }

    public void setMortgageable(Boolean mortgageable) {
        isMortgageable = mortgageable;
    }

    public Long getUserMinBorrow() {
        return userMinBorrow;
    }

    public void setUserMinBorrow(Long userMinBorrow) {
        this.userMinBorrow = userMinBorrow;
    }

    public Long getUserMinRepay() {
        return userMinRepay;
    }

    public void setUserMinRepay(Long userMinRepay) {
        this.userMinRepay = userMinRepay;
    }

    @Override
    public String toString() {
        return "CryptoAssets{" +
                "assetName='" + assetName + '\'' +
                ", assetFullName='" + assetFullName + '\'' +
                ", isBorrowable=" + isBorrowable +
                ", isMortgageable=" + isMortgageable +
                ", userMinBorrow=" + userMinBorrow +
                ", userMinRepay=" + userMinRepay +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CryptoAssets that = (CryptoAssets) o;
        return assetName.equals(that.assetName) &&
                assetFullName.equals(that.assetFullName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(assetName, assetFullName);
    }

    public static String transformCoinObjectToSting(CryptoAssets coin){
        return coin.getAssetFullName() + "(" + coin.getAssetName()  + ")";
    }

    public static CryptoAssets transformStringCoinToObject(String coinText){
        String[] coinTextSeparated = coinText.split("[\\\\(\\\\)]");
        return new CryptoAssets(
                coinTextSeparated[1],
                coinTextSeparated[0]);
    }

    public static ArrayList<CryptoAssets> transformArrayStringCoinToObjects(ArrayList<String> coins){
        ArrayList<CryptoAssets> cryptoAssetsArrayList = new ArrayList<>();

        for(String coin: coins)
            cryptoAssetsArrayList.add(transformStringCoinToObject(coin));

        return cryptoAssetsArrayList;
    }
}
