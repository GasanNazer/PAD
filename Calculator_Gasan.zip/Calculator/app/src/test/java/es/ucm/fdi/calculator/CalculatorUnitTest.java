package es.ucm.fdi.calculator;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CalculatorUnitTest {
    @Test
    public void add() {
        assertEquals(3, 1 + 2);
    }
}
