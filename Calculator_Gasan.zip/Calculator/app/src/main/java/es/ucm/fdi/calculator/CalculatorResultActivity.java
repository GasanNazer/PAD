package es.ucm.fdi.calculator;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CalculatorResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator_result);

        TextView result = (TextView) findViewById(R.id.viewResult);

        Intent intent = getIntent();
        Integer sum = intent.getIntExtra("SUM", 0);
        result.setText(Integer.toString(sum));
    }

}
