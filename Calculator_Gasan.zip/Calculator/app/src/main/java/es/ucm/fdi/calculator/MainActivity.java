package es.ucm.fdi.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    Calculator calculator = new Calculator();
    EditText editTextX, editTextY;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "Starting onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextX = findViewById(R.id.numberX);
        editTextY = findViewById(R.id.numberY);
        Log.d(TAG, "Finishing onCreate");
    }

    public void addXandY(View view){
        String valueX= editTextX.getText().toString();
        try {
            int finalValueX = Integer.parseInt(valueX);
            Log.d(TAG, "X: " + finalValueX);

            String valueY = editTextY.getText().toString();
            int finalValueY = Integer.parseInt(valueY);
            Log.d(TAG, "Y: " + finalValueY);

            int resultado = calculator.add(finalValueX, finalValueY);
            Log.d(TAG, "Result: " + resultado);

            Intent intent = new Intent(this, CalculatorResultActivity.class);
            intent.putExtra("SUM", resultado);

            Log.d(TAG, "Starting CalculatorResultActivity");
            startActivity(intent);
        } catch (Exception e) {
            e.getMessage();
            Log.e(TAG, e.getMessage());
        }
    }

}