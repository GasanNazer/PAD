package es.ucm.fdi.calculator;

public class Calculator {

    public Integer add(Integer x, Integer y){
        return x + y;
    }
}
